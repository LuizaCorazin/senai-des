const db = require("../data/connection")

const especialidades = [];

const listarespecialidades = async (req, res) => {
    const lista = await db.query("SELECT * FROM especialidade");
    res.json(lista[0]).end();
}

const buscarespecialidade = async (req, res) => {
    const idespecialidade = req.params.id;
    const especialidade = await db.query("SELECT * FROM especialidade WHERE id =" + idespecialidade);
    res.json(especialidade[0][0]).end();
}

const cadastrarespecialidade = (req, res) => {
  const data = req.body;
  especialidade.push(data);
  res.status(201).send("Cadastrado Com Sucesso").end();
}


const excluirespecialidade = async (req, res) => {
    const id = req.params.id;

    try{
        const remove = await db.query("DELETE FROM especialidade WHERE id = ?", [id]);

        console.log(remove);

        res.status(200).end();
    } catch(error){
        console.log(error);

        const err = { msg : ""};

        if(error.errno === 1451){
            err.msg = "Usuario com  registrada";
        }

        res.json(err).status(500).end();
    }
};

const atualizarespecialidade = async (req, res) => {
    const {id, nome} = req.body;

    try {
        const update = await db.query("UPDATE especialidade SET nome = ? where id = ?", [nome, id]);

        const info = { msg : "" };

        if(update[0].affectedRows === 1) {
            info.msg = "Atulizado com sucesso";
        }else if(update[0].affectedRows === 0){
            info.msg = "Usuario não encontrado";
        }
       
        res.status(200).json(info).end();

    }catch (error){
        console.log(error);

        res.status(500).end();
    }
};


module.exports = {
    listarespecialidades,
    buscarespecialidade,
    cadastrarespecialidade,
    excluirespecialidade,
    atualizarespecialidade
}